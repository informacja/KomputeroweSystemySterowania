%nic
nn=1; 
return;