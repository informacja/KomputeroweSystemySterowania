# Sygnał

## Main Topic 3

## Częstotliwość

## Kształt

## Siła

## Main Topic 2

*XMind - Trial Version*